export interface TableElement {
    id: number;
    name: string;
    tableId: number;
  }
  