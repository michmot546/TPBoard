// src/app/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private http: HttpClient) {}

  private apiUrl = 'http://localhost:7134/api/User';

  login(credentials: { login: string; password: string }): Observable<any> {
    return this.http.post('http://localhost:7134/api/User/login', credentials);
  }

  register(data: { login: string; email: string; password: string; name: string; }): Observable<any> {
    return this.http.post('http://localhost:7134/api/User/register', data);
  }
}
